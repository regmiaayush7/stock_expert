# Technical Analysis on Adjusted Prices (`technical-analysis.md`)

## Core Rule
**Always adjust price history for bonus, right shares, and cash dividends before computing any indicator.** Unadjusted NEPSE charts create false crashes and false breakouts.

## Indicator Customisation for NEPSE (10% Daily Band)
- **RSI (14)**: Measures momentum. In NEPSE's 10% circuit band, extreme momentum can sustain longer; overbought (>70) and oversold (<30) thresholds should be confirmed by volume and breadth.
- **MACD (12, 26, 9)**: Trend-following momentum. Crossovers are filtered through volume expansion.
- **Moving Averages (SMA/EMA 20, 50, 200)**: Primary trend filters. 50-day and 200-day MAs define medium and long-term regimes.
- **ATR (14)**: Average True Range measures volatility, essential for stop-loss placement given the 10% daily limit.
- **OBV (On-Balance Volume)**: Accumulation/distribution confirmation via volume flow.
- **Relative Strength**: Stock performance relative to the NEPSE Index or its specific sector index.
